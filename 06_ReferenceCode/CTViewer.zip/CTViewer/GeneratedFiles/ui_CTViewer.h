/********************************************************************************
** Form generated from reading UI file 'CTViewer.ui'
**
** Created by: Qt User Interface Compiler version 5.6.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CTVIEWER_H
#define UI_CTVIEWER_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QFrame>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenu>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>
#include "QVTKWidget.h"

QT_BEGIN_NAMESPACE

class Ui_CTViewerClass
{
public:
    QAction *open_action;
    QAction *save_action;
    QAction *action_4;
    QWidget *centralWidget;
    QWidget *layoutWidget;
    QGridLayout *gridLayout;
    QVTKWidget *qvtkWidget;
    QVTKWidget *qvtkWidget_2;
    QVTKWidget *qvtkWidget_4;
    QVTKWidget *qvtkWidget_3;
    QFrame *frame;
    QCheckBox *checkBox;
    QMenuBar *menuBar;
    QMenu *file_menu;
    QMenu *tool_menu;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *CTViewerClass)
    {
        if (CTViewerClass->objectName().isEmpty())
            CTViewerClass->setObjectName(QStringLiteral("CTViewerClass"));
        CTViewerClass->resize(1195, 927);
        open_action = new QAction(CTViewerClass);
        open_action->setObjectName(QStringLiteral("open_action"));
        save_action = new QAction(CTViewerClass);
        save_action->setObjectName(QStringLiteral("save_action"));
        action_4 = new QAction(CTViewerClass);
        action_4->setObjectName(QStringLiteral("action_4"));
        centralWidget = new QWidget(CTViewerClass);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        layoutWidget = new QWidget(centralWidget);
        layoutWidget->setObjectName(QStringLiteral("layoutWidget"));
        layoutWidget->setGeometry(QRect(351, 8, 651, 751));
        gridLayout = new QGridLayout(layoutWidget);
        gridLayout->setSpacing(6);
        gridLayout->setContentsMargins(11, 11, 11, 11);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        gridLayout->setContentsMargins(0, 0, 0, 0);
        qvtkWidget = new QVTKWidget(layoutWidget);
        qvtkWidget->setObjectName(QStringLiteral("qvtkWidget"));

        gridLayout->addWidget(qvtkWidget, 0, 0, 1, 1);

        qvtkWidget_2 = new QVTKWidget(layoutWidget);
        qvtkWidget_2->setObjectName(QStringLiteral("qvtkWidget_2"));

        gridLayout->addWidget(qvtkWidget_2, 0, 1, 1, 1);

        qvtkWidget_4 = new QVTKWidget(layoutWidget);
        qvtkWidget_4->setObjectName(QStringLiteral("qvtkWidget_4"));

        gridLayout->addWidget(qvtkWidget_4, 1, 1, 1, 1);

        qvtkWidget_3 = new QVTKWidget(layoutWidget);
        qvtkWidget_3->setObjectName(QStringLiteral("qvtkWidget_3"));

        gridLayout->addWidget(qvtkWidget_3, 1, 0, 1, 1);

        frame = new QFrame(centralWidget);
        frame->setObjectName(QStringLiteral("frame"));
        frame->setGeometry(QRect(50, 20, 260, 714));
        QSizePolicy sizePolicy(QSizePolicy::Fixed, QSizePolicy::Preferred);
        sizePolicy.setHorizontalStretch(1);
        sizePolicy.setVerticalStretch(1);
        sizePolicy.setHeightForWidth(frame->sizePolicy().hasHeightForWidth());
        frame->setSizePolicy(sizePolicy);
        frame->setMinimumSize(QSize(260, 0));
        frame->setFrameShape(QFrame::StyledPanel);
        frame->setFrameShadow(QFrame::Raised);
        checkBox = new QCheckBox(frame);
        checkBox->setObjectName(QStringLiteral("checkBox"));
        checkBox->setGeometry(QRect(20, 30, 71, 16));
        CTViewerClass->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(CTViewerClass);
        menuBar->setObjectName(QStringLiteral("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 1195, 23));
        file_menu = new QMenu(menuBar);
        file_menu->setObjectName(QStringLiteral("file_menu"));
        tool_menu = new QMenu(menuBar);
        tool_menu->setObjectName(QStringLiteral("tool_menu"));
        CTViewerClass->setMenuBar(menuBar);
        mainToolBar = new QToolBar(CTViewerClass);
        mainToolBar->setObjectName(QStringLiteral("mainToolBar"));
        CTViewerClass->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(CTViewerClass);
        statusBar->setObjectName(QStringLiteral("statusBar"));
        CTViewerClass->setStatusBar(statusBar);

        menuBar->addAction(file_menu->menuAction());
        menuBar->addAction(tool_menu->menuAction());
        file_menu->addAction(open_action);
        file_menu->addSeparator();
        file_menu->addAction(save_action);
        tool_menu->addAction(action_4);

        retranslateUi(CTViewerClass);

        QMetaObject::connectSlotsByName(CTViewerClass);
    } // setupUi

    void retranslateUi(QMainWindow *CTViewerClass)
    {
        CTViewerClass->setWindowTitle(QApplication::translate("CTViewerClass", "CTViewer", 0));
        open_action->setText(QApplication::translate("CTViewerClass", "\346\211\223\345\274\200", 0));
        save_action->setText(QApplication::translate("CTViewerClass", "\344\277\235\345\255\230", 0));
        action_4->setText(QApplication::translate("CTViewerClass", "\351\207\215\351\207\207\346\240\267", 0));
        checkBox->setText(QApplication::translate("CTViewerClass", "CheckBox", 0));
        file_menu->setTitle(QApplication::translate("CTViewerClass", "\346\226\207\344\273\266", 0));
        tool_menu->setTitle(QApplication::translate("CTViewerClass", "\345\267\245\345\205\267", 0));
    } // retranslateUi

};

namespace Ui {
    class CTViewerClass: public Ui_CTViewerClass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CTVIEWER_H
