#ifndef PROJECTMAINWINDOW_H
#define PROJECTMAINWINDOW_H

#include <QtWidgets/QMainWindow>
#include "ui_CTViewer.h"

#include <vtkSmartPointer.h>


class vtkImageViewer2;
class vtkRenderer;
class vtkEventQtSlotConnect;
class vtkObject;
class vtkCommand;
class vtkResliceImageViewer;
class vtkImagePlaneWidget;
class vtkDistanceWidget;
class vtkResliceImageViewerMeasurements;

class CTViewer : public QMainWindow
{
	Q_OBJECT

public:
	CTViewer(QWidget *parent = 0);
	~CTViewer();

	private slots:
	//��Ӧ��ͼ���ļ��Ĳۺ���
	void onOpenSlot();

	//��Ӧ����ƶ�����Ϣ��ʵʱ������ĵ�ǰλ��
	void updateCoords(vtkObject* obj);

protected:
	vtkSmartPointer< vtkResliceImageViewer > riw[3];
	vtkSmartPointer< vtkImagePlaneWidget > planeWidget[3];
	vtkSmartPointer< vtkDistanceWidget > DistanceWidget[3];
	vtkSmartPointer< vtkResliceImageViewerMeasurements > ResliceMeasurements;


private:
	vtkSmartPointer< vtkImageViewer2 >           m_pImageViewer;
	vtkSmartPointer< vtkRenderer >                   m_pRenderder;

	vtkEventQtSlotConnect* m_Connections;

private:
	Ui::CTViewerClass ui;
};

#endif // PROJECTMAINWINDOW_H
