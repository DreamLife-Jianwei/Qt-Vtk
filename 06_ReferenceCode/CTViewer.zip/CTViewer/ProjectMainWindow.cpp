#include "ProjectMainWindow.h"

//#include <QFileDialog>
//#include <QFileDialog>
#include <QFileDialog>
//#include <qfiledialog.h>
#include <QDir>
#include <vtkRenderWindow.h>
#include <vtkRenderer.h>
#include <vtkImageViewer2.h>
#include <QVTKWidget.h>
#include <vtkJPEGReader.h>
#include <vtkImageActor.h>
#include <vtkEventQtSlotConnect.h>
#include <vtkCommand.h>
#include <vtkDICOMImageReader.h>
#include "vtkSmartPointer.h"
#include "vtkResliceImageViewer.h"
#include "vtkImagePlaneWidget.h"
#include "vtkDistanceWidget.h"
#include "vtkResliceImageViewerMeasurements.h"
//#include <QMainWindow>
#include "vtkResliceCursorLineRepresentation.h"
#include "vtkImageData.h"
#include "vtkCellPicker.h"

#include <vtkRenderer.h>
#include <vtkRenderWindow.h>
#include "vtkResliceImageViewer.h"
#include "vtkResliceCursorLineRepresentation.h"
#include "vtkResliceCursorThickLineRepresentation.h"
#include "vtkResliceCursorWidget.h"
#include "vtkResliceCursorActor.h"
#include "vtkResliceCursorPolyDataAlgorithm.h"
#include "vtkResliceCursor.h"
#include "vtkDICOMImageReader.h"
#include "vtkCellPicker.h"
#include "vtkProperty.h"
#include "vtkPlane.h"
#include "vtkImageData.h"
#include "vtkCommand.h"
#include "vtkPlaneSource.h"
#include "vtkLookupTable.h"
#include "vtkImageMapToWindowLevelColors.h"
#include "vtkInteractorStyleImage.h"
#include "vtkImageSlabReslice.h"
#include "vtkBoundedPlanePointPlacer.h"
#include "vtkDistanceWidget.h"
#include "vtkDistanceRepresentation.h"
#include "vtkHandleRepresentation.h"
#include "vtkResliceImageViewerMeasurements.h"
#include "vtkDistanceRepresentation2D.h"
#include "vtkPointHandleRepresentation3D.h"
#include "vtkPointHandleRepresentation2D.h"


CTViewer::CTViewer(QWidget *parent)
	: QMainWindow(parent)
{
	ui.setupUi(this);

	vtkSmartPointer< vtkDICOMImageReader > reader =
		vtkSmartPointer< vtkDICOMImageReader >::New();
	//reader->SetDirectoryName(argv[1]);
	reader->SetDirectoryName("C://Users//123456//Desktop//LUNG AND LIVER//LUNG//2");
	//reader->SetDirectoryName("C:\Users\123456\Desktop\LUNG AND LIVER\LUNG\2");
	reader->Update();


	int imageDims[3];
	reader->GetOutput()->GetDimensions(imageDims);


	for (int i = 0; i < 3; i++)
	{
		riw[i] = vtkSmartPointer< vtkResliceImageViewer >::New();
	}
	
	ui.qvtkWidget->SetRenderWindow(riw[0]->GetRenderWindow());
	riw[0]->SetupInteractor(
		ui.qvtkWidget->GetRenderWindow()->GetInteractor());

	ui.qvtkWidget_2->SetRenderWindow(riw[1]->GetRenderWindow());
	riw[1]->SetupInteractor(
		ui.qvtkWidget_2->GetRenderWindow()->GetInteractor());

	ui.qvtkWidget_3->SetRenderWindow(riw[2]->GetRenderWindow());
	riw[2]->SetupInteractor(
		ui.qvtkWidget_3->GetRenderWindow()->GetInteractor());

	for (int i = 0; i < 3; i++)
	{
		// make them all share the same reslice cursor object.
		vtkResliceCursorLineRepresentation *rep =
			vtkResliceCursorLineRepresentation::SafeDownCast(
			riw[i]->GetResliceCursorWidget()->GetRepresentation());
		riw[i]->SetResliceCursor(riw[0]->GetResliceCursor());

		rep->GetResliceCursorActor()->
			GetCursorAlgorithm()->SetReslicePlaneNormal(i);

		riw[i]->SetInputData(reader->GetOutput());
		riw[i]->SetSliceOrientation(i);
		riw[i]->SetResliceModeToAxisAligned();
	}

	vtkSmartPointer<vtkCellPicker> picker =
		vtkSmartPointer<vtkCellPicker>::New();
	picker->SetTolerance(0.005);

	vtkSmartPointer<vtkProperty> ipwProp =
		vtkSmartPointer<vtkProperty>::New();

	vtkSmartPointer< vtkRenderer > ren =
		vtkSmartPointer< vtkRenderer >::New();

	ui.qvtkWidget_4->GetRenderWindow()->AddRenderer(ren);
	vtkRenderWindowInteractor *iren = ui.qvtkWidget_4->GetInteractor();

	for (int i = 0; i < 3; i++)
	{
		planeWidget[i] = vtkSmartPointer<vtkImagePlaneWidget>::New();
		planeWidget[i]->SetInteractor(iren);
		planeWidget[i]->SetPicker(picker);
		planeWidget[i]->RestrictPlaneToVolumeOn();
		double color[3] = { 0, 0, 0 };
		color[i] = 1;
		planeWidget[i]->GetPlaneProperty()->SetColor(color);

		color[0] /= 4.0;
		color[1] /= 4.0;
		color[2] /= 4.0;
		riw[i]->GetRenderer()->SetBackground(color);

		planeWidget[i]->SetTexturePlaneProperty(ipwProp);
		planeWidget[i]->TextureInterpolateOff();
		planeWidget[i]->SetResliceInterpolateToLinear();
		planeWidget[i]->SetInputConnection(reader->GetOutputPort());
		planeWidget[i]->SetPlaneOrientation(i);
		planeWidget[i]->SetSliceIndex(imageDims[i] / 2);
		planeWidget[i]->DisplayTextOn();
		planeWidget[i]->SetDefaultRenderer(ren);
		planeWidget[i]->SetWindowLevel(1358, -27);
		planeWidget[i]->On();
		planeWidget[i]->InteractionOn();
	}

	////// ����m_QVTKWidget����Ⱦ��
	//m_QVTKWidget->GetRenderWindow()->AddRenderer(m_pRenderder);

	////���Ӵ򿪵��ź�����Ӧ�Ĳ�
	connect(ui.open_action, SIGNAL(triggered()), this, SLOT(onOpenSlot()));

	m_Connections = vtkEventQtSlotConnect::New();
	//m_Connections->Connect(m_QVTKWidget->GetRenderWindow()->GetInteractor(),
	//	vtkCommand::MouseMoveEvent,
	//	this,
	//	SLOT(updateCoords(vtkObject*)));
}

CTViewer::~CTViewer()
{

}

void CTViewer::onOpenSlot()
{
	QString filter;
	filter = "DICM image file (*.dcm)";

	QDir dir;
	QString fileName = QFileDialog::getOpenFileName(this, QString(tr("��ͼ��")), dir.absolutePath(), filter);
	if (fileName.isEmpty() == true)
		return;
	
	// ֧�ִ�����·���Ķ�ȡ
	QByteArray ba = fileName.toLocal8Bit();
	const char *fileName_str = ba.data();
}

void CTViewer::updateCoords(vtkObject* obj)
{
	// ��ȡ������
	vtkRenderWindowInteractor* iren = vtkRenderWindowInteractor::SafeDownCast(obj);

	// ��ȡ���ĵ�ǰλ��
	int event_pos[2];
	iren->GetEventPosition(event_pos);

	QString str;
	str.sprintf("x=%d : y=%d", event_pos[0], event_pos[1]);
	//m_StatusBar->showMessage(str);
}
